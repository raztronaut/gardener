// Gardyn — growth trajectory for the Gardyn Studio 2 "Budding Florist" kit
// (16 pods: 15 varieties, Stock Flower planted twice), sown 2026-09-20 and placed
// per Gardyn's official Studio layout. Lights: 14 h/day Sep 20–22, 16 h/day from
// Sep 23 (see LIGHT_SCHEDULE — growth windows are scaled by actual light hours).
//
// The card is a compact timeline: one row per plant on a shared 0–120 day axis,
// showing the expected SPROUT window (faint) and the first BLOOM / HARVEST window
// (solid), with a single "today" line across every row — so a glance answers
// "how far is each plant from growing, and when do my flowers open?". Colour
// encodes the plant's kind (flower / herb / green); names are direct labels.
// Fullscreen adds the pod layout, the care calendar and per-plant notes.
//
// All timings are Gardyn's own published ranges (help.mygardyn.com plant pages +
// care-cycle guides); they're estimates from the planting date, not sensor reads.

const START = '2026-09-20';          // sow day = day 0
// Daily light hours, by the day they took effect (Gardyn recommends 14–16 h).
const LIGHT_SCHEDULE = [{ from: '2026-09-20', h: 14 }, { from: '2026-09-23', h: 16 }];
const LIGHT_HOURS = LIGHT_SCHEDULE[LIGHT_SCHEDULE.length - 1].h; // current schedule
// Gardyn's published ranges don't say which schedule they assume, so treat them as
// the middle of its recommended 14–16 h. Growth after sprouting scales with light
// (daily light integral ∝ hours): a 16 h day = 16/15 of a baseline day. Germination
// is driven by water + warmth, so sprout windows are NOT scaled.
const BASE_HOURS = 15;
const AXIS_DAYS = 120;               // shared timeline span (snapdragon tops out ~115)
const KIT = 'Budding Florist';
const DEVICE = 'Gardyn Studio 2';

// Validated (dataviz validator, dark surface) categorical palette — kind of plant.
const KINDS = {
  flower: { label: 'Flowers', color: '#d9528e' },
  herb: { label: 'Herbs', color: '#9a7cf0' },
  green: { label: 'Greens', color: '#1fa874' },
};

// sp = sprout window (days), m = first bloom / first-cut window (days), pos = pods.
// Leafy greens: Gardyn says most are ready to harvest in 3–5 weeks (first outer-leaf
// cut at ~4 in), so their window starts at day 21 and runs to full size.
export const PLANTS = [
  { n: 'White Petunia', k: 'flower', sp: [7, 12], m: [30, 40], pos: ['R5'], ht: '1 ft, trails',
    note: 'Not edible. If it has sprouted but shows no true leaves 14 days later, add plant food. Trails as it grows; deadhead spent blooms.' },
  { n: 'Stock Flower', k: 'flower', sp: [5, 10], m: [65, 80], pos: ['R2', 'R6'], ht: 'under 1 ft',
    note: 'Fragrant pink / purple spikes. Won’t bloom if it’s too warm (likes 55–75°F). Remove the whole spent head at the stalk base so side shoots follow.' },
  { n: 'Sunflower', k: 'flower', sp: [10, 14], m: [65, 75], pos: ['L3'], ht: '1 ft',
    note: 'Dwarf and pollen-free — keep just 1 sprout. Gives 20+ blooms over 3–4 waves.' },
  { n: 'Celosia Mix', k: 'flower', sp: [7, 14], m: [75, 100], pos: ['L7'], ht: '2 ft',
    note: 'Feathery magenta, orange and yellow plumes. Watch for aphids.' },
  { n: 'Purple Snapdragon', short: 'Snapdragon', k: 'flower', sp: [7, 20], m: [80, 115], pos: ['R4'], ht: '8–10 in',
    note: 'Blooms in several waves — deadhead to keep them coming. Cut at 45° above a leaf node, leaving a third of the plant.' },
  { n: 'Bull’s Blood Beet', k: 'green', sp: [5, 10], m: [21, 35], pos: ['R7'], ht: '1 ft',
    note: 'Deep-red leaves; harvest for 4–5 weeks.' },
  { n: 'Yellow Swiss Chard', k: 'green', sp: [7, 21], m: [28, 60], pos: ['L4'], ht: '1 ft',
    note: 'Harvest the outer leaves once they reach 3 in.' },
  { n: 'Breen', k: 'green', sp: [7, 21], m: [21, 45], pos: ['L6'], ht: 'under 1 ft',
    note: 'Harvest outer leaves at 4 in; productive for 3–5 weeks.' },
  { n: 'Butterhead', k: 'green', sp: [7, 21], m: [21, 45], pos: ['R3'], ht: 'under 1 ft',
    note: 'Harvest outer leaves at 4 in; prefers 60–70°F.' },
  { n: 'Green Salanova', k: 'green', sp: [7, 14], m: [21, 55], pos: ['L2'], ht: 'under 1 ft',
    note: 'Harvest outer leaves at 4 in.' },
  { n: 'Red Sorrel', k: 'herb', sp: [7, 14], m: [60, 75], pos: ['L1'], ht: 'under 1 ft',
    note: 'Lemony red-veined leaves; harvest for 3–4 weeks. Watch for thrips.' },
  { n: 'Bunching Onions', k: 'herb', sp: [7, 21], m: [60, 60], pos: ['L8'], ht: '1 ft',
    note: 'Cut at 6–8 in down to 2 in — they regrow in 1–2 weeks.' },
  { n: 'Lemon Balm', k: 'herb', sp: [7, 14], m: [70, 70], pos: ['R1'], ht: '2 ft',
    note: 'Start trimming at 10 in; harvest for 8–12 weeks.' },
  { n: 'Purple Basil', k: 'herb', sp: [5, 10], m: [72, 72], pos: ['L5'], ht: '1 ft',
    note: 'Pinch off flower buds to delay bolting; likes it warm (70–85°F).' },
  { n: 'Pink Celery', k: 'green', sp: [12, 20], m: [75, 100], pos: ['R8'], ht: '1 ft',
    note: 'Slow to sprout. Add plant food 10 days after sprouting; harvest stalks at 6 in+.' },
];

// What the humans have actually done. Recorded from the wall (✓ Done buttons in the
// fullscreen view → POST /api/gardyn/log, persisted server-side); this is only the
// fallback when the server log can't be read. tasks: id → ISO date; water: [{date, kind}].
export const DEFAULT_LOG = {
  tasks: { sprout: '2026-09-28' }, // sprout dose: 1 tsp (white spoon) straight into the 3 gal tank (≈⅓ tsp/gal; no extra water)
  water: [],
};

// One-off care tasks (days from sowing). Watering + feeding is NOT here — it's the
// weekly water plan below, anchored on the day the sprout dose was given.
const CARE = [
  // Dose rule is ¼ tsp per gallon for EVERY gallon in the tank. Gardyn's Studio figure
  // (¾ tsp) assumes a 2 gal start; this tank started with 3 gal, so 3 + 1 = 4 gal → 1 tsp
  // (one level white Gardyn spoon, which is 1 tsp).
  { id: 'sprout', long: "Mix ¾–1 tsp plant food into a gallon of water and pour it into the tank — the plants' first food.", ic: 'spoon', short: 'Sprout dose', d: 7, to: 14, t: 'Sprout dose', how: '1 white spoon (1 tsp) food + 1 gal water → tank',
    s: 'Once most pods have sprouted: mix 1 tsp (the white Gardyn spoon, level) of plant food into 1 gal of warm water, shake, pour it all into the tank. Rule: ¼ tsp per gallon in the tank — 3 gal start + this 1 gal = 4 gal. Water only until then.' },
  { id: 'thin', long: 'Snip the extra sprouts at the base — keep 1 per pod for greens & sunflower, 3 for herbs & flowers.', ic: 'scissors', short: 'Thin sprouts', after: 'sprout', d: 5, to: 7, t: 'Mini harvest', how: 'thin: snip extras, keep 1–3 per pod',
    s: '5–7 days after the sprout dose. Cut extras at the base with clean scissors (don’t pull). Keep 1 for greens & sunflower, 3 for herbs and small flowers. Green, lettuce and herb thinnings are edible — that’s the “mini harvest”.' },
  { id: 'replace', long: 'Look for pods with no sprout at all. Gardyn replaces those free — request them in the Gardyn app.', ic: 'search', short: 'Empty-pod check', d: 22, t: 'Empty-pod check (free replacements)', how: 'any pod still bare → Gardyn sends a free one',
    s: 'Any pod still unsprouted today qualifies for Gardyn’s replacement guarantee.' },
  { id: 'petunia', long: 'First petunia flowers. Pinch off each bloom once it fades so new ones keep coming.', ic: 'flower', short: 'Petunias bloom', d: 30, g: true, t: 'Petunias start blooming', how: 'pinch off spent blooms',
    s: 'First flowers of the kit. Deadhead spent blooms to keep them coming.' },
  { id: 'roots', long: 'Lift the top off and look at the roots: white is healthy; snip any brown, slimy bits.', ic: 'roots', short: 'Check roots', d: 60, g: true, t: 'Check the roots', how: 'healthy = white; trim any brown mush',
    s: 'Plants are maturing and blooming — check roots every 2–4 weeks from now.' },
  { id: 'stock', long: 'Stock and sunflowers start blooming. Cut finished stock spikes at the base.', ic: 'flower', short: 'Stock blooms', d: 65, g: true, t: 'Stock & sunflower blooms', how: 'keep the room under ~75°F for stock',
    s: 'Expect the first stock spikes and sunflowers. Keep the room under ~75°F for stock.' },
  { id: 'snap', long: 'Snapdragons open. Cut finished stems just above a leaf to get another wave.', ic: 'flower', short: 'Snapdragons', d: 80, g: true, t: 'Snapdragons open', how: 'cut at 45° above a leaf node',
    s: 'Snapdragon blooms arrive in waves.' },
  { id: 'refresh', long: 'Most plants are past their best — swap tired pods for new ones.', ic: 'sprout', short: 'Replant', d: 180, t: 'Refresh the garden', how: 'swap tired pods for new ones',
    s: 'Most Gardyn plants last ~6 months — swap tired yCubes for new ones.' },
];

// Line icons (24px grid, round 1.8 stroke, currentColor) — the wall's icon style.
const ICON = {
  drop: '<path d="M12 3.6c3.1 4 6 7.1 6 10.4a6 6 0 0 1-12 0c0-3.3 2.9-6.4 6-10.4z"/>',
  refresh: '<path d="M19.5 12a7.5 7.5 0 1 1-2.2-5.3"/><path d="M19.5 4.5v4h-4"/>',
  scissors: '<circle cx="6.5" cy="7" r="2.6"/><circle cx="6.5" cy="17" r="2.6"/><path d="M8.8 8.4 19.5 17.5M8.8 15.6 19.5 6.5"/>',
  leaf: '<path d="M5 19.5C5 11 10 5 19.5 4.5 19.5 14 14 19 5.5 19"/><path d="M5 19.5c3-4.5 6-7.5 10-10"/>',
  flower: '<circle cx="12" cy="12" r="2.2"/><path d="M12 9.8C9.6 7.6 10.2 4 12 3.5c1.8.5 2.4 4.1 0 6.3zM12 14.2c2.4 2.2 1.8 5.8 0 6.3-1.8-.5-2.4-4.1 0-6.3zM9.8 12C7.6 14.4 4 13.8 3.5 12 4 10.2 7.6 9.6 9.8 12zM14.2 12c2.2-2.4 5.8-1.8 6.3 0-.5 1.8-4.1 2.4-6.3 0z"/>',
  sprig: '<path d="M12 21V9"/><path d="M12 14c-4.2 0-6.2-2.3-6.2-5.4 3.3 0 6.2 1.6 6.2 5.4zM12 11c4.2 0 6.2-2.3 6.2-5.4-3.3 0-6.2 1.6-6.2 5.4z"/>',
  spoon: '<ellipse cx="12" cy="7" rx="3.6" ry="4.4"/><path d="M12 11.4V21"/>',
  search: '<circle cx="11" cy="11" r="6"/><path d="M20 20l-4.6-4.6"/>',
  roots: '<path d="M12 3v8"/><path d="M12 11c-1.5 2.5-4.5 3.8-6.5 8M12 11c1.5 2.5 4.5 3.8 6.5 8M12 11v9"/>',
  check: '<path d="M5 12.5l4.5 4.5L19 7.5"/>',
  back: '<path d="M19 12H5M11 6l-6 6 6 6"/>',
  sun: '<circle cx="12" cy="12" r="4"/><path d="M12 2.5v2M12 19.5v2M2.5 12h2M19.5 12h2M5.3 5.3l1.4 1.4M17.3 17.3l1.4 1.4M5.3 18.7l1.4-1.4M17.3 6.7l1.4-1.4"/>',
  sprout: '<path d="M12 21v-8"/><path d="M12 13c0-4-3-6-7-6 0 4 3 6 7 6zM12 13c0-3 2.5-5 6-5 0 3-2.5 5-6 5z"/>',
};
function icon(name, cls = '') {
  const el = document.createElement('span');
  el.className = `ic ${cls}`.trim();
  el.innerHTML = `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${ICON[name] || ''}</svg>`;
  return el;
}
const KIND_ICON = { flower: 'flower', green: 'leaf', herb: 'sprig' };
const WATER_ICON = { top: 'drop', refresh: 'refresh', dose: 'spoon' };

const DAY = 864e5;
const startMs = Date.parse(START + 'T00:00:00Z');
function todayIndex(tz) {
  const key = new Intl.DateTimeFormat('en-CA', { timeZone: tz, year: 'numeric', month: '2-digit', day: '2-digit' }).format(new Date());
  return Math.round((Date.parse(key + 'T00:00:00Z') - startMs) / DAY);
}
const dateOf = (d) => new Date(startMs + d * DAY);
const fmtShort = (d) => dateOf(d).toLocaleDateString('en-US', { month: 'short', day: 'numeric', timeZone: 'UTC' });
// Light-scaled clock: baseline (15 h) days accumulated by the end of calendar day c.
const hoursOn = (c) => {
  let h = LIGHT_SCHEDULE[0].h;
  for (const s of LIGHT_SCHEDULE) if (Math.round((Date.parse(s.from + 'T00:00:00Z') - startMs) / DAY) <= c) h = s.h;
  return h;
};
// Calendar day on which a baseline-day milestone b is reached.
export function calDay(b) {
  let c = 0, eff = 0;
  for (;;) {
    const r = hoursOn(c) / BASE_HOURS;
    if (eff + r >= b || c > 400) return Math.round(c + (b - eff) / r);
    eff += r; c++;
  }
}
for (const p of PLANTS) { p.base = p.m; p.m = p.m.map(calDay); }
for (const c of CARE) if (c.g) { c.d = calDay(c.d); if (c.to != null) c.to = calDay(c.to); }
const dayOfIso = (iso) => Math.round((Date.parse(iso + 'T00:00:00Z') - startMs) / DAY);
const endOf = (c) => (c.to != null ? c.to : c.d);

// Tasks resolved against the log: done dates attached, and relative tasks
// (thinning) counted from when the step they follow was actually done.
function tasks(log = DEFAULT_LOG) {
  const done = (log && log.tasks) || {};
  const out = CARE.map((c) => ({ ...c, done: done[c.id] ? dayOfIso(done[c.id]) : null }));
  for (const c of out) if (c.after) {
    const prev = out.find((x) => x.id === c.after);
    const base = prev.done != null ? prev.done : endOf(prev);
    c.d += base; if (c.to != null) c.to += base;
  }
  return out;
}

// Feeding strength follows growth (Gardyn): ¼ tsp/gal from the sprout dose, ½ once
// true leaves / ½ in roots show, 1 tsp once plants mature and bloom.
const TRUE_LEAVES = calDay(21), MATURE = calDay(60);
const perGalOn = (d) => (d < TRUE_LEAVES ? 0.25 : d < MATURE ? 0.5 : 1);
const tsp = (x) => ({ 0.25: '¼', 0.5: '½', 0.75: '¾' }[x] || String(x));
const fmtDay = (d) => dateOf(d).toLocaleDateString('en-US', { weekday: 'short', month: 'short', day: 'numeric', timeZone: 'UTC' });

// The water plan: the next waterings, every 7 days after the LAST watering you
// recorded (or the sprout dose). A slot ≥ 25 days after the last tank refresh (or
// the first fill on day 0) is a full refresh instead of a top-off. Unrecorded past
// slots stay at the front, shown as overdue, until you mark them done.
export function waterPlan(fromDay, n = 6, log = DEFAULT_LOG) {
  const ts = tasks(log);
  const sprout = ts.find((c) => c.id === 'sprout');
  if (sprout.done == null) {
    return [{ d: Math.max(fromDay, sprout.d), kind: 'dose', t: sprout.t, amt: sprout.how, s: sprout.s }];
  }
  const water = ((log && log.water) || []).map((w) => ({ d: dayOfIso(w.date), kind: w.kind }));
  let anchor = Math.max(sprout.done, ...water.map((w) => w.d));
  let lastRefresh = Math.max(0, ...water.filter((w) => w.kind === 'refresh').map((w) => w.d));
  const out = [];
  for (let k = 1; out.length < n && k < 80; k++) {
    const d = anchor + 7 * k;
    const g = perGalOn(d);
    if (d - lastRefresh >= 25) {
      lastRefresh = d;
      out.push({ d, kind: 'refresh', t: 'Tank refresh', amt: `4 gal water + ${tsp(g * 4)} tsp food`, short: `refill + ${tsp(g * 4)} tsp`,
        s: `Drain the tank, wipe it with baking soda, rinse, refill to 4 gal and mix in ${tsp(g * 4)} tsp plant food (${tsp(g)} tsp per gallon).` });
    } else {
      out.push({ d, kind: 'top', t: 'Check water', amt: `if low: ${tsp(g)} tsp food per gal you add`, short: 'check level',
        s: `Look at the app’s water tile. At ¾ or more, do nothing. Below that, add water back toward 4 gal — mix ${tsp(g)} tsp plant food into each gallon first. The water already in the tank keeps its food.` });
    }
  }
  return out;
}

// The next one-off task still to do (not done, window not over).
export function nextTask(day, log = DEFAULT_LOG) {
  return tasks(log).filter((c) => c.done == null && endOf(c) >= day).sort((a, b) => a.d - b.d)[0] || null;
}
// Everything recorded as done, newest last: tasks + waterings.
export function doneLog(log = DEFAULT_LOG) {
  const t = tasks(log).filter((c) => c.done != null).map((c) => ({ id: c.id, t: c.t, d: c.done }));
  const w = ((log && log.water) || []).map((x) => ({ id: 'water', date: x.date, t: x.kind === 'refresh' ? 'Tank refresh' : x.kind === 'dose' ? 'Sprout dose' : 'Water check', d: dayOfIso(x.date) }));
  return [...t, ...w].sort((a, b) => a.d - b.d);
}
const rangeTxt = ([a, b]) => (a === b ? `day ${a} (${fmtShort(a)})` : `day ${a}–${b} (${fmtShort(a)} – ${fmtShort(b)})`);

// Where one plant is on its trajectory, given today's day index.
export function plantStatus(p, day) {
  const flower = p.k === 'flower';
  if (day < p.sp[0]) return { phase: 'seed', label: `${p.m[0] - day}d`, sub: 'germinating' };
  if (day <= p.sp[1]) return { phase: 'sprout', label: `${p.m[0] - day}d`, sub: 'sprouting' };
  if (day < p.m[0]) return { phase: 'grow', label: `${p.m[0] - day}d`, sub: 'growing' };
  if (day <= p.m[1]) return { phase: 'ready', label: flower ? 'blooming' : 'ready', sub: flower ? 'first blooms' : 'harvest' };
  return { phase: 'ongoing', label: flower ? 'in bloom' : 'harvest', sub: 'producing' };
}

// The garden's overall stage.
export function gardenStage(day) {
  if (day < 0) return 'Not planted yet';
  if (day < 7) return 'Germinating';
  if (day < 22) return 'Sprouting';
  if (day < 30) return 'Seedlings';
  if (day < 65) return 'Growing';
  if (day < 180) return 'Blooming';
  return 'Past prime';
}

// Step-by-step how-tos (Gardyn help center wording, condensed). Shown when a task
// or watering row is tapped in the fullscreen view. video = official Gardyn video;
// link = the Gardyn help article. Both become QR codes for the phone.
const HELP = 'https://help.mygardyn.com/en/articles/';
const HOWTO = {
  thin: {
    need: ['Clean, sharp scissors'],
    steps: [
      'Look at each pod and pick the strongest-looking sprouts to keep (see the list).',
      'Snip every other sprout at its base, as close to the cube as you can.',
      'Don’t pull them out — pulling tears the roots of the ones you keep.',
      'Eat the lettuce, green and herb snippings (skip petunia — not edible).',
    ],
    perPod: true,
    video: { label: 'Gardyn · How to Thin Your Sprouts', url: 'https://www.youtube.com/watch?v=L8A5-MuoMQQ' },
    link: HELP + '1771329',
  },
  sprout: {
    need: ['White Gardyn spoon (1 tsp)', '1-gallon jug', 'Warm tap water'],
    steps: [
      'Fill the jug with 1 gallon of warm tap water.',
      'Add 1 level white spoon (1 tsp) of plant food — it’s ¼ tsp per gallon for the whole tank.',
      'Shake until it dissolves, then pour all of it into the tank.',
    ],
    link: HELP + '2526145',
  },
  top: {
    need: ['White Gardyn spoon (1 tsp)', '1-gallon jug', 'Warm tap water'],
    steps: [
      'Check the water tile in the Gardyn app. At ¾ full or more, you’re done — nothing to add.',
      'If it’s lower, fill the jug with 1 gallon of warm tap water.',
      'Stir in the plant food powder for that gallon ({amt}) — e.g. ¼ tsp = a quarter of the white spoon — and shake until dissolved.',
      'Lift the small wooden cap on the lid and pour it in.',
      'Repeat one gallon at a time until the tank reads 4 gal.',
    ],
    link: HELP + '1777985',
  },
  refresh: {
    need: ['Towel', 'Soft sponge + baking soda', '1-gallon jug', 'Plant food + white spoon'],
    steps: [
      'Switch off and unplug the Gardyn; put a towel down.',
      'Lift the pump up, unlock the lid, and stand the top half on the towel (lift by the columns, not the lights).',
      'Pour out the old water; wipe the tank with a soft sponge and baking soda, then rinse.',
      'Refill 1 gallon at a time with warm water mixed with food ({amt}) until it holds 4 gal.',
      'Put the top half back, lower the pump, lock the lid, plug in — give it ~5 min to restart.',
      'Log the refresh in the Gardyn app (resets its 28-day countdown).',
    ],
    link: HELP + '1788097',
  },
  replace: {
    need: [],
    steps: [
      'Look at all 16 pods. Note any with no sprout at all (use the L1–R8 numbers).',
      'Those qualify for Gardyn’s free replacement — request them in the Gardyn app or from Gardyn support.',
      'Leave slow pods (pink celery, bunching onions) a few more days if they’re just starting.',
    ],
    link: HELP + '1772865',
  },
  petunia: { need: ['Fingers or small scissors'], steps: ['When a flower fades, pinch it off just below the bloom.', 'Keep doing it — removing spent blooms keeps new ones coming.'], link: HELP + '1866945' },
  stock: { need: ['Small scissors'], steps: ['When a flower spike is spent, cut the whole spike off at its base.', 'Side shoots then grow new spikes. Stock won’t bloom if the room is above ~75°F.'], link: HELP + '1783425' },
  snap: { need: ['Small scissors'], steps: ['Cut finished stems at 45°, just above a leaf node.', 'Leave about a third of the plant — it blooms again in waves.'], link: HELP + '2400513' },
  roots: { need: ['Towel'], steps: ['Unplug and lift the top half onto a towel (same as a tank refresh).', 'Healthy roots are white or cream and firm.', 'Snip off any brown, slimy roots with clean scissors, then reassemble.'], link: HELP + '1772865' },
};
const KEEP = (p) => (p.k === 'green' || p.n === 'Sunflower' ? 1 : 3);

// Compat: active = tasks in their window today; upcoming = later tasks.
export function nextCare(day, log = DEFAULT_LOG) {
  const todo = tasks(log).filter((c) => c.done == null).sort((a, b) => a.d - b.d);
  return { active: todo.filter((c) => c.to != null && day >= c.d && day <= c.to), upcoming: todo.filter((c) => c.d > day) };
}

const pct = (d) => `${(Math.max(0, Math.min(AXIS_DAYS, d)) / AXIS_DAYS) * 100}%`;
const MONTHS = (() => {
  const out = [];
  const s = dateOf(0);
  for (let i = 1; i <= 4; i++) {
    const m = new Date(Date.UTC(s.getUTCFullYear(), s.getUTCMonth() + i, 1));
    const d = Math.round((m - startMs) / DAY);
    if (d <= AXIS_DAYS) out.push({ d, t: m.toLocaleDateString('en-US', { month: 'short', timeZone: 'UTC' }).toUpperCase() });
  }
  return out;
})();

const STYLE = `
  .gd { display:flex; flex-direction:column; height:100%; min-height:0; gap:7px; }
  .gd-top { flex:0 0 auto; display:flex; align-items:baseline; gap:12px; }
  .gd > .gd-top { margin-bottom:18px; } /* room between the header and the chart's month axis */
  .gd-day { font-family:var(--font-display); font-size:27px; line-height:1; color:var(--ink); }
  .gd-st { font-family:var(--font-display); font-size:27px; line-height:1; color:var(--mint); }
  /* today's answer, top-right: quiet when nothing's due, gold when something is */
  .gd-today { margin-left:auto; display:inline-flex; align-items:center; gap:6px; font-size:15px; color:var(--ink-soft); white-space:nowrap; }
  .gd-today .ic { font-size:16px; color:var(--mint); }
  .gd-today.due { color:var(--gold); font-weight:600; }
  .gd-today.due .ic { color:var(--gold); }
  /* the next two steps — an agenda (hairlines, no boxes), like Out in SF */
  .gd-agenda { flex:0 0 auto; display:flex; flex-direction:column; }
  .gd-ag { display:grid; grid-template-columns:20px 1fr auto 34px; align-items:center; column-gap:9px; padding:5px 0;
    border-bottom:1px solid var(--stroke); font-size:16.5px; color:var(--ink); }
  .gd-ag:first-child { border-top:1px solid var(--stroke); }
  .gd-ag .ic { font-size:18px; align-self:start; margin-top:2px; }
  .gd-ag .lb { min-width:0; }
  /* the explanation runs under the whole row (all columns after the icon), up to 2 lines */
  .gd-ag .wh { grid-column:2 / -1; grid-row:2; font-size:14.5px; line-height:1.25; color:var(--ink-soft);
    display:-webkit-box; -webkit-line-clamp:2; -webkit-box-orient:vertical; overflow:hidden; margin-top:2px; }
  .gd-ag .dt, .gd-ag .in { align-self:start; margin-top:1px; }
  .gd-ag.water .ic { color:#5fb6ff; }
  .gd-ag.task .ic { color:var(--gold); }
  .gd-ag .dt { font-size:15px; color:var(--ink-soft); }
  .gd-ag .in { font-size:15px; color:var(--ink-faint); text-align:right; }
  /* axis care icons — WHAT happens on that date */
  .gd-axis .am { position:absolute; top:15px; transform:translateX(-50%); display:flex; flex-direction:column; align-items:center; gap:1px; }
  .gd-axis .am .ics { display:flex; gap:1px; font-size:13px; }
  .gd-axis .am .ic.w { color:#5fb6ff; }
  .gd-axis .am .ic.t { color:var(--gold); }
  .gd-axis .am .dn { font-size:12.5px; line-height:1; color:var(--ink-soft); }

  .gd-chart { flex:1; min-height:0; display:flex; flex-direction:column; }
  .gd-row, .gd-axis, .gd-mlines { display:grid; grid-template-columns: 146px 1fr 44px; align-items:center; column-gap:10px; }
  .gd-rows { position:relative; }
  .gd-mlines { position:absolute; inset:0; pointer-events:none; align-items:stretch; }
  .gd-mlines .trk { position:relative; }
  .gd-mlines .ml { position:absolute; top:0; bottom:0; border-left:1px dashed rgba(140,240,195,.22); }
  .gd-axis { height:44px; flex:0 0 auto; }
  .gd > .gd-chart > .gd-axis { margin-bottom:12px; } /* tile: room between the month axis and the plant bars */
  .gd-axis .wk { position:absolute; bottom:0; width:1px; height:3px; background:var(--stroke-strong); }
  .gd-axis .cm { position:absolute; bottom:0; width:2px; height:6px; margin-left:-1px; border-radius:1px; }
  .gd-axis .cm.w { background:#5fb6ff; }
  .gd-axis .cm.t { background:var(--gold); }
  /* care rails — icons on the shared time axis */
  .gd-rails { flex:0 0 auto; display:flex; flex-direction:column; gap:4px; margin:6px 0 8px; }
  .gd-row.rail { flex:0 0 20px; height:20px; min-height:0; }
  .gd-row.rail.water { --c:#5fb6ff; }
  .gd-row.rail.task { --c:var(--gold); }
  .gd-row.rail .nm { color:var(--c); font-weight:600; }
  .gd-row.rail .tr::before { background:color-mix(in srgb, var(--c) 18%, transparent); }
  .gd-row.rail .mk { position:absolute; top:50%; transform:translate(-50%,-50%); display:grid; place-items:center;
    font-size:10px; color:var(--c); opacity:.45; }
  .gd-row.rail .mk.next { font-size:12px; opacity:1; width:20px; height:20px; border-radius:50%;
    background:color-mix(in srgb, var(--c) 22%, #0d1f19); }
  .gd-row.rail .mk.done { color:var(--ink-faint); opacity:.6; font-size:9px; }
  .gd-row.rail .mk.dot { width:3px; height:3px; border-radius:50%; background:var(--c); opacity:.5; }
  .gd-row.rail .rt { color:var(--c); }
  .gd-row.rail .rt.due { font-weight:600; }
  .gd-axis .ticks { position:relative; height:100%; }
  .gd-axis .tk { position:absolute; top:0; transform:translateX(-50%); font-family:var(--font);
    font-size:12.5px; letter-spacing:.08em; color:var(--ink-soft); }
  .gd-rows { flex:1; min-height:0; display:flex; flex-direction:column; justify-content:space-evenly; }
  /* rows give up a couple of px each (never below 17px) when both agenda steps run
     to two lines, instead of pushing the last plant out of the card */
  .gd-row { flex:0 1 21px; height:21px; min-height:17px; }
  .gd-row .nm { font-size:16px; color:var(--ink); white-space:nowrap; overflow:hidden; text-overflow:ellipsis; }
  .gd-row.grp .nm { color:var(--ink-soft); }
  .gd-row .tr { position:relative; height:100%; }
  .gd-row .tr::before { content:''; position:absolute; left:0; right:0; top:50%; height:1px; background:var(--stroke); }
  .gd-row .sp { position:absolute; top:50%; height:5px; margin-top:-2.5px; border-radius:2px; opacity:.35; }
  .gd-row .mw { position:absolute; top:50%; height:10px; margin-top:-5px; border-radius:5px; min-width:6px; }
  .gd-row.grp .mw { opacity:.5; }
  .gd-row .now { position:absolute; top:-3px; bottom:-3px; width:1.5px; margin-left:-.75px; background:var(--gold); }
  .gd-row .rt { font-family:var(--font-mono); font-size:15px; color:var(--ink-soft); text-align:right; white-space:nowrap; }
  .gd-row.ready .rt { color:var(--mint); font-weight:600; }
  .ic { display:inline-flex; width:1em; height:1em; flex:0 0 auto; }
  .ic svg { width:100%; height:100%; }
  .gd-row .nm { display:flex; align-items:center; gap:6px; min-width:0; }
  /* flex kills text-overflow on bare text, so the label lives in its own span:
     the name ellipsizes while the ×N count always stays visible. */
  .gd-row .nm .lb { flex:0 1 auto; min-width:0; overflow:hidden; text-overflow:ellipsis; white-space:nowrap; }
  .gd-row .nm .ct { flex:none; font-size:13px; color:var(--ink-faint); }
  .gd-row .ic.kind { font-size:15px; }
`;

const kindIcon = (k) => { const e = icon(KIND_ICON[k], 'kind'); e.style.color = KINDS[k].color; return e; };
const tip = (p) => `${p.n}${p.pos.length > 1 ? ' ×2' : ''} · pod ${p.pos.join(' & ')} · sprouts ${rangeTxt(p.sp)} · `
  + `${p.k === 'flower' ? 'first blooms' : 'first cut'} ${rangeTxt(p.m)}`;
const bar = (h, cls, a, b, c) => h('div', { class: cls, style: { left: pct(a), width: `calc(${pct(b)} - ${pct(a)})`, background: c } });

// One plant = one row (sprout window faint, first bloom / cut window solid).
function row(h, p, day, compact = false) {
  const c = KINDS[p.k].color;
  const st = plantStatus(p, day);
  const ready = st.phase === 'ready' || st.phase === 'ongoing';
  return h('div', { class: `gd-row${ready ? ' ready' : ''}`, title: tip(p) },
    h('div', { class: 'nm' }, kindIcon(p.k), h('span', { class: 'lb' }, (compact && p.short) || p.n),
      p.pos.length > 1 ? h('span', { class: 'ct' }, '×2') : null),
    h('div', { class: 'tr' },
      bar(h, 'sp', p.sp[0], p.sp[1], c),
      bar(h, 'mw', p.m[0], p.m[1], c),
      day >= 0 && day <= AXIS_DAYS ? h('div', { class: 'now', style: { left: pct(day) } }) : null),
    h('div', { class: 'rt' }, ready ? (p.k === 'flower' ? 'bloom' : 'ready') : `${p.m[0] - day}d`));
}

// A whole kind collapsed into one row: every member's window drawn as a
// translucent segment on the same track (overlaps read darker).
function groupRow(h, kind, plants, day) {
  const c = KINDS[kind].color;
  const first = Math.min(...plants.map((p) => p.m[0]));
  const ready = plants.some((p) => day >= p.m[0]);
  return h('div', { class: `gd-row grp${ready ? ' ready' : ''}`, title: plants.map(tip).join('\n') },
    h('div', { class: 'nm' }, kindIcon(kind), h('span', { class: 'lb' }, KINDS[kind].label),
      h('span', { class: 'ct' }, `×${plants.length}`)),
    h('div', { class: 'tr' },
      ...plants.map((p) => bar(h, 'mw', p.m[0], p.m[1], c)),
      day >= 0 && day <= AXIS_DAYS ? h('div', { class: 'now', style: { left: pct(day) } }) : null),
    h('div', { class: 'rt' }, ready ? 'ready' : `${first - day}d`));
}

// "in 3 days" / "today" / "tomorrow" / "overdue 2d".
const inDays = (d, day) => (d === day ? 'today' : d === day + 1 ? 'tomorrow' : d > day ? `in ${d - day} days` : `${day - d}d overdue`);

// What needs doing: everything due today (or overdue), then the next steps.
function agenda(day, log) {
  const { water, task } = careEvents(day, log);
  const all = [...water.map((e) => ({ ...e, k: 'water' })), ...task.map((e) => ({ ...e, k: 'task' }))]
    .sort((a, b) => a.d - b.d);
  const due = all.filter((e) => e.d <= day);
  const next = all.filter((e) => e.d > day);
  return { due, next };
}
// "in 6d" style day count (or today / Nd late), shared by the tile + how-tos.
const daysTxt = (d, day) => (d === day ? 'today' : d < day ? `${day - d}d late` : `${d - day}d`);

// Care lives ON the timeline: two thin rails (Water, Tasks) share the plants' time
// axis. Every upcoming step is a tiny icon at its date; the next one is lit, named
// in the row label, and counted down in the right column like the plant rows. Done
// steps stay behind as faint ticks. The axis carries weekly ticks + a short colour
// mark under each care date, and today's line runs through everything.
function careEvents(day, log) {
  const water = waterPlan(day, 18, log).filter((w) => w.d <= AXIS_DAYS)
    .map((w) => ({ src: w, kind: w.kind, d: w.d, ic: WATER_ICON[w.kind], minor: w.kind === 'top', label: w.kind === 'refresh' ? 'Tank refresh' : w.kind === 'dose' ? 'Sprout dose' : 'Check water',
      what: w.kind === 'refresh' ? `Drain the tank, wipe it clean, then refill with ${w.amt}.`
        : w.kind === 'dose' ? w.amt
        : `Look at the water level in the Gardyn app. If it's below ¾, add water with ${w.amt.replace(/^if low: /, '').replace(/ you add$/, '')}; otherwise nothing to do.`,
      tip: `${w.t} — ${w.amt}` }));
  const task = tasks(log).filter((c) => c.done == null && endOf(c) >= day && c.d <= AXIS_DAYS).sort((a, b) => a.d - b.d)
    .map((c) => ({ src: c, id: c.id, d: c.d, to: c.to, ic: c.ic, label: c.short, what: c.long || c.how, tip: `${c.t} — ${c.how}` }));
  const done = doneLog(log).filter((e) => e.d >= 0 && e.d <= AXIS_DAYS);
  return { water, task, done };
}
function rail(h, cls, evs, done, day) {
  const next = evs[0];
  // Routine weekly checks are quiet dots; only the next step and the notable ones
  // (tank refresh, tasks) get an icon.
  const mk = (e, extra) => (extra === '' && e.minor
    ? h('span', { class: 'mk dot', style: { left: pct(e.d) }, title: e.tip || '' })
    : h('span', { class: `mk ${extra}`, style: { left: pct(e.d) }, title: e.tip || '' }, icon(extra === 'done' ? 'check' : e.ic)));
  const due = next && day >= next.d;
  return h('div', { class: `gd-row rail ${cls}`, title: next ? `${next.tip} · ${fmtDay(next.d)}` : '' },
    h('div', { class: 'nm' }, h('span', { class: 'lb' }, next ? next.label : '—')),
    h('div', { class: 'tr' },
      ...done.map((e) => mk(e, 'done')),
      ...evs.map((e, i) => mk(e, i === 0 ? 'next' : '')),
      day >= 0 && day <= AXIS_DAYS ? h('div', { class: 'now', style: { left: pct(day) } }) : null),
    h('div', { class: `rt${due ? ' due' : ''}` }, next ? (due ? 'now' : `${next.d - day}d`) : ''));
}
function chart(h, day, detailed, log = DEFAULT_LOG) {
  // Ranked by how soon each plant (or group) reaches its first harvest / bloom.
  const soon = (a, b) => a.m[0] - b.m[0] || a.m[1] - b.m[1];
  const of = (k) => PLANTS.filter((p) => p.k === k).sort(soon);
  const first = (ps) => ({ m: [Math.min(...ps.map((p) => p.m[0])), Math.min(...ps.map((p) => p.m[1]))] });
  const rows = detailed
    ? [...PLANTS].sort(soon).map((p) => row(h, p, day))
    : [...of('flower').map((p) => ({ ...p, el: () => row(h, p, day, true) })),
      ...['green', 'herb'].map((k) => ({ ...first(of(k)), el: () => groupRow(h, k, of(k), day) }))]
      .sort(soon).map((r) => r.el());
  // Axis marks carry meaning: an icon at each notable care date (tank refresh,
  // thinning, replacement check, blooms…) — routine weekly checks are left off.
  const care = careEvents(day, log);
  // Only real chores (blooms are already the pink bars; weekly checks are routine).
  const marks = [...care.water.filter((e) => !e.minor), ...care.task.filter((e) => ['sprout', 'thin', 'replace', 'roots', 'refresh'].includes(e.id))].filter((e) => e.d > day);
  return h('div', { class: 'gd-chart' },
    h('div', { class: 'gd-axis' }, h('div', {}),
      h('div', { class: 'ticks' },
        ...MONTHS.map((m) => h('span', { class: 'tk', style: { left: pct(m.d) } }, m.t)),
        // one mark per date: the chore icon(s) with the day-of-month under it
        // (the month name sits above), so each symbol says WHEN.
        ...[...new Set(marks.map((e) => e.d))].sort((a, b) => a - b).map((d) => {
          const es = marks.filter((e) => e.d === d);
          return h('span', { class: 'am', style: { left: pct(d) }, title: es.map((e) => `${e.label} · ${fmtDay(d)}`).join('\n') },
            h('span', { class: 'ics' }, ...es.map((e) => { const i = icon(e.ic); i.classList.add(care.water.includes(e) ? 'w' : 't'); return i; })),
            h('span', { class: 'dn' }, String(dateOf(d).getUTCDate())));
        })),
      h('div', {})),
    h('div', { class: 'gd-rows' },
      // dashed month separators, one continuous line per month across every row
      h('div', { class: 'gd-mlines' }, h('div', {}),
        h('div', { class: 'trk' }, ...MONTHS.map((m) => h('i', { class: 'ml', style: { left: pct(m.d) } }))), h('div', {})),
      ...rows));
}

// The care log lives on the wall server (so ✓ Done survives reloads). Shared by the
// tile and the fullscreen view; any change notifies both.
let LOG = DEFAULT_LOG;
async function loadLog() {
  try { const r = await fetch('/api/gardyn', { cache: 'no-store' }); if (r.ok) LOG = (await r.json()).log || LOG; } catch { /* keep last */ }
  return LOG;
}
async function record(body) {
  const r = await fetch('/api/gardyn/log', { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify(body) });
  if (!r.ok) throw new Error(`log ${r.status}`);
  LOG = (await r.json()).log;
  window.dispatchEvent(new Event('gardyn:log'));
}

// The tile's two "coming up" rows: routine weekly water checks repeat with the
// same title + how-to, so after the first one (or after one already due today)
// they're noise — prefer the next DISTINCT steps (tank refresh, a task). Tops up
// with the skipped checks only if there's nothing else to show.
function tileNext(due, next) {
  let seenWater = due.some((e) => e.k === 'water');
  const keep = next.filter((e) => {
    if (e.k !== 'water' || !e.minor) return true;
    if (seenWater) return false;
    seenWater = true;
    return true;
  });
  return (keep.length >= 2 ? keep : [...keep, ...next.filter((e) => !keep.includes(e))]).slice(0, 2)
    .sort((a, b) => a.d - b.d);
}

function build(h, body, tz, log = LOG) {
  const day = todayIndex(tz);
  // (the "Today: Check water +2" line was removed 2026-10-30 — the humans found it
  // pointless on the tile; the day's steps live in the full view)
  body.replaceChildren(h('div', { class: 'gd' },
    h('div', { class: 'gd-top' },
      h('div', { class: 'gd-day' }, `Day ${Math.max(0, day)}`),
      h('div', { class: 'gd-st' }, gardenStage(day))),
    // (the tile's "coming up" rows — Tank refresh / Check roots weeks ahead — were removed
    // 2026-10-30 too; the full view keeps the whole agenda)
    chart(h, day, false, log)));
}

export default {
  id: 'gardyn',
  title: 'Gardyn',
  icon: '🌸',
  size: 'tall',
  chrome: true,
  async mount(body, ctx) {
    const { h } = ctx;
    const tz = (ctx.config && ctx.config.tz) || 'America/Los_Angeles';
    ctx.style(STYLE);
    build(h, body, tz);
    loadLog().then(() => build(h, body, tz));
    const onLog = () => { if (body.isConnected) build(h, body, tz); else window.removeEventListener('gardyn:log', onLog); };
    window.addEventListener('gardyn:log', onLog);
    // The day only changes at midnight — an hourly refresh is plenty (text + divs only).
    ctx.interval(() => loadLog().then(() => build(h, body, tz)), 60 * 60 * 1000);
  },

  // Fullscreen: headline milestones, the full trajectory, the pod tower and
  // what's coming up. Deliberately light on text — details live in tooltips.
  async openFull(body, ctx) {
    const { h } = ctx;
    const tz = (ctx.config && ctx.config.tz) || 'America/Los_Angeles';
    ctx.style(STYLE + FULL_STYLE);
    await loadLog();
    const render = () => renderFull(h, body, todayIndex(tz), LOG);
    render();
    const onLog = () => { if (body.isConnected) render(); else window.removeEventListener('gardyn:log', onLog); };
    window.addEventListener('gardyn:log', onLog);
  },
};

// ✓ Done / undo button: records to the server, then both views re-render.
function actBtn(h, label, payload, cls = '', title = 'Mark done') {
  const b = h('button', { class: `gx-btn ${cls}`, type: 'button', title, 'aria-label': title }, label);
  // Two taps: the first arms it ("tap again"), a second within 4 s records —
  // so a stray tap on the wall can't log something that didn't happen.
  let armed = 0;
  b.addEventListener('click', async (e) => {
    e.stopPropagation();
    if (Date.now() - armed > 4000) {
      armed = Date.now(); b.classList.add('arm'); b.title = 'Tap again to confirm';
      setTimeout(() => { if (Date.now() - armed >= 4000) { b.classList.remove('arm'); b.title = title; } }, 4100);
      return;
    }
    b.disabled = true;
    try { await record(payload); } catch { b.disabled = false; b.classList.add('err'); }
  });
  return b;
}

// QR for the phone (same quickchart route the corner Roots QR uses).
const qr = (h, url) => h('img', { class: 'hw-qr', alt: '', src: `/api/proxy?url=${encodeURIComponent(
  `https://quickchart.io/qr?text=${encodeURIComponent(url)}&dark=0c1f19&light=ffffff&ecLevel=M&margin=2&size=260&format=png`)}` });

// How-to for one task / watering: what, when, what you need, numbered steps, the
// per-pod keep list for thinning, and QR codes for the video + Gardyn article.
function renderHow(h, body, key, item, day, log) {
  const hw = HOWTO[key];
  const back = h('button', { class: 'hw-back gbtn quiet', type: 'button' }, icon('back'), 'Back');
  back.addEventListener('click', () => renderFull(h, body, day, log));
  const ic = item.ic || WATER_ICON[item.kind] || 'sprout';
  const when = item.to != null ? `${fmtDay(item.d)} – ${fmtDay(item.to)}` : fmtDay(item.d);
  const fill = (t) => t.replace('{amt}', item.amt || '');
  const steps = hw ? hw.steps.map(fill) : [item.how || item.amt || '', item.s || ''].filter(Boolean);
  let pods = null;
  if (hw?.perPod) {
    const byPos = {};
    for (const p of PLANTS) for (const ps of p.pos) byPos[ps] = p;
    const cell = (ps) => { const p = byPos[ps]; return h('div', { class: `hw-pod k${KEEP(p)}` }, h('span', { class: 'ps' }, ps), kindIcon(p.k),
      h('span', { class: 'n' }, p.n.replace(/^(Purple|Yellow|Green|White|Red) (?=Snapdragon|Swiss|Salanova|Petunia|Sorrel)/, '')), h('b', {}, `keep ${KEEP(p)}`)); };
    pods = h('section', { class: 'gx-sec' }, h('div', { class: 'gx-h' }, h('span', {}, 'Keep per pod'), h('span', { class: 'key' }, 'top → bottom')),
      h('div', { class: 'hw-pods' }, ...Array.from({ length: 8 }, (_, i) => [cell('L' + (i + 1)), cell('R' + (i + 1))]).flat()));
  }
  const codes = h('div', { class: 'hw-qrs' },
    hw?.video ? h('div', { class: 'hw-q' }, qr(h, hw.video.url), h('div', {}, h('b', {}, 'Watch the video'), h('div', { class: 'sub' }, hw.video.label))) : null,
    hw?.link ? h('div', { class: 'hw-q' }, qr(h, hw.link), h('div', {}, h('b', {}, 'Gardyn guide'), h('div', { class: 'sub' }, 'help.mygardyn.com'))) : null);
  body.replaceChildren(h('div', { class: 'gx hw' },
    back,
    h('div', { class: 'hw-hero' }, h('div', { class: 'hw-ic' }, icon(ic)),
      h('div', {}, h('div', { class: 'hw-t' }, item.t), h('div', { class: 'hw-when' }, `${when} · ${item.to != null && day >= item.d && day <= item.to ? 'now' : daysTxt(item.d, day)}`))),
    hw?.need?.length ? h('div', { class: 'hw-need' }, h('span', { class: 'lbl' }, 'You need'), ...hw.need.map((n) => h('span', { class: 'chip' }, n))) : null,
    h('ol', { class: 'hw-steps' }, ...steps.map((t) => h('li', {}, t))),
    pods,
    codes));
}

// Fullscreen = the tile, expanded: same header + "today" answer, then ONE list of
// what's coming (plain instruction, date, days, ✓, tap → how-to), the milestones as
// one line, the full timeline, feeding in one sentence, and the pod tower. Open
// rows and hairlines — no tiles, boxes or chips.
function renderFull(h, body, day, log) {
  const { due, next } = agenda(day, log);
  // the next water step + every notable step (routine weekly checks after the first are noise)
  let seenWater = false;
  const items = [...due, ...next].filter((e) => {
    if (e.k !== 'water') return true;
    if (!seenWater) { seenWater = true; return true; }
    return !e.minor;
  }).slice(0, 4);
  const firstWater = items.find((e) => e.k === 'water');
  const row = (e) => {
    const isDue = e.d <= day;
    const canDo = e.d - day <= 3 && (e.k === 'task' || e === firstWater);
    const payload = e.k === 'water'
      ? (e.kind === 'dose' ? { id: 'sprout', action: 'done' } : { id: 'water', kind: e.kind, action: 'done' })
      : { id: e.id, action: 'done' };
    const el = h('div', { class: `fx-row ${e.k}${isDue ? ' due' : ''}`, title: 'Tap for step-by-step' },
      h('span', { class: 'ri' }, icon(e.ic)),
      h('div', { class: 'tx' }, h('div', { class: 'nm' }, e.label), h('div', { class: 'wh' }, e.what || '')),
      h('div', { class: 'when' }, h('div', { class: 'dt' }, fmtDay(e.d)), h('div', { class: 'in' }, isDue ? 'today' : `in ${e.d - day} days`)),
      canDo ? actBtn(h, icon('check'), payload) : h('span', { class: 'gx-btn-sp' }));
    el.addEventListener('click', () => renderHow(h, body, e.k === 'water' ? (e.kind === 'dose' ? 'sprout' : e.kind) : e.id, e.src, day, log));
    return el;
  };
  const today = due.length
    ? h('div', { class: 'gd-today due' }, icon(due[0].ic), h('span', {}, `Today: ${due.map((e) => e.label).join(', ')}`))
    : h('div', { class: 'gd-today' }, icon('check'), h('span', {}, 'Nothing today'));

  const firstOf = (k) => Math.min(...PLANTS.filter((p) => p.k === k).map((p) => p.m[0]));
  const ms = (k, what) => { const d = firstOf(k); return h('span', { class: 'ms' }, kindIcon(k), h('b', {}, what), ` ${fmtShort(d)}`, h('i', {}, d > day ? ` · ${d - day} days` : ' · now')); };

  const chartEl = chart(h, day, true, log);

  const byPos = {};
  for (const p of PLANTS) for (const ps of p.pos) byPos[ps] = p;
  const col = (side) => h('div', { class: 'gx-col' }, ...Array.from({ length: 8 }, (_, i) => {
    const p = byPos[side + (i + 1)];
    return h('div', { class: 'gx-pod', title: `${p.n} — ${p.note}` },
      kindIcon(p.k), h('span', { class: 'n' }, p.n.replace(/^(Purple|Yellow) (?=Snapdragon|Swiss)/, '')), h('span', { class: 'ps' }, side + (i + 1)));
  }));

  const done = doneLog(log).slice(-4);
  const sec = (t, ...kids) => h('section', { class: 'fx-sec' }, h('div', { class: 'fx-h' }, t), ...kids);
  body.replaceChildren(h('div', { class: 'gx fx' },
    h('div', { class: 'fx-head' },
      h('div', { class: 'gd-day' }, `Day ${Math.max(0, day)}`), h('div', { class: 'gd-st' }, gardenStage(day)), today),
    h('div', { class: 'fx-sub' }, `${DEVICE} · ${KIT} · sown ${fmtShort(0)} · ${LIGHT_HOURS}h of light a day`),
    sec('Coming up', h('div', { class: 'fx-list' }, ...items.map(row)),
      done.length ? h('div', { class: 'fx-done' }, h('span', { class: 'lb' }, 'Done'),
        ...done.map((c) => actBtn(h, [icon('check'), h('span', {}, `${c.t} · ${fmtShort(c.d)}`)],
          c.id === 'water' ? { id: 'water', date: c.date, action: 'undo' } : { id: c.id, action: 'undo' }, 'undo', 'Tap twice to undo'))) : null),
    sec('Milestones', h('div', { class: 'fx-ms' }, ms('green', 'First greens'), ms('flower', 'First flowers'), ms('herb', 'Herbs'))),
    h('section', { class: 'fx-sec gf-chart' }, h('div', { class: 'fx-h' }, 'Every plant'), chartEl),
    h('div', { class: 'fx-pair' },
      sec('Feeding', h('div', { class: 'fx-feed' }, icon('spoon'),
        h('span', {}, 'Mix plant food into the water before it goes in: ', h('b', {}, '¼ tsp per gallon'),
          ` now, ½ tsp from ${fmtShort(TRUE_LEAVES)}, 1 tsp from ${fmtShort(MATURE)}. The white Gardyn spoon is 1 tsp.`))),
      sec('The tower · top to bottom', h('div', { class: 'gx-tower' }, col('L'), h('div', { class: 'spine' }), col('R'))))));
}

const FULL_STYLE = `
  /* ---- fullscreen v2 ---- */
  .fx { gap:14px; padding:0 30px 0; }
  .fx-head { display:flex; align-items:baseline; gap:14px; }
  .fx-head .gd-day, .fx-head .gd-st { font-size:44px; }
  .fx-head .gd-today { font-size:18px; }
  .fx-head .gd-today .ic { font-size:19px; }
  .fx-sub { margin-top:-12px; font-size:15px; color:var(--ink-soft); }
  .fx-h { font-family:var(--font-display); font-size:14px; font-weight:700; letter-spacing:.1em; text-transform:uppercase;
    color:var(--ink-soft); margin-bottom:10px; }
  .fx-list { display:flex; flex-direction:column; border-top:1px solid var(--stroke); }
  .fx-row { display:grid; grid-template-columns:26px 1fr auto 40px; column-gap:14px; align-items:center; padding:8px 0;
    border-bottom:1px solid var(--stroke); cursor:var(--c-hand); }
  .fx-row .ri { font-size:22px; display:flex; align-self:start; margin-top:2px; }
  .fx-row.water .ri { color:#5fb6ff; }
  .fx-row.task .ri { color:var(--gold); }
  .fx-row .nm { font-size:19px; color:var(--ink); }
  .fx-row .wh { font-size:15px; line-height:1.35; color:var(--ink-soft); margin-top:3px; }
  .fx-row .when { text-align:right; align-self:start; margin-top:2px; white-space:nowrap; }
  .fx-row .dt { font-size:15px; color:var(--ink); }
  .fx-row .in { font-size:13px; color:var(--ink-faint); margin-top:2px; }
  .fx-row.due .nm, .fx-row.due .in { color:var(--gold); }
  .fx-row .gx-btn { align-self:center; }
  .fx-done { display:flex; flex-wrap:wrap; align-items:center; gap:4px 16px; margin-top:12px; }
  .fx-done .lb { font-size:13px; color:var(--ink-faint); }
  .fx-done .gx-btn.undo { width:auto; height:auto; border-radius:999px; padding:4px 6px; background:none; color:var(--ink-soft);
    display:inline-flex; align-items:center; gap:6px; font-size:14px; font-weight:400; }
  .fx-done .gx-btn.undo .ic { color:var(--mint); }
  .fx-done .gx-btn.undo.arm { color:var(--gold); box-shadow:none; }
  .fx-ms { display:flex; flex-wrap:wrap; gap:8px 28px; font-size:17px; color:var(--ink-soft); }
  .fx-ms .ms { display:inline-flex; align-items:center; gap:7px; }
  .fx-ms .ms .ic { font-size:17px; }
  .fx-ms b { color:var(--ink); font-weight:600; }
  .fx-ms i { font-style:normal; color:var(--ink-faint); }
  .fx-feed { display:flex; gap:12px; font-size:17px; line-height:1.45; color:var(--ink-soft); }
  .fx-feed .ic { font-size:22px; color:#5fb6ff; margin-top:2px; }
  .fx-feed b { color:var(--ink); font-weight:600; }
  .fx .gf-chart .gd-row { flex-basis:19px; height:19px; }
  .fx .gx-pod { height:24px; }
  .fx-pair { display:grid; grid-template-columns:minmax(0,.8fr) minmax(0,1.2fr); gap:28px; align-items:start; }
  .fx-pair .gx-tower { max-width:none; margin:0; }
  .fx .gf-chart .gd-axis { height:56px !important; margin:0 0 6px !important; }
  .fx .gf-chart .gd-axis .tk { font-size:13px; }
  .fx .gf-chart .gd-axis .am { top:22px; }
  .fx .gf-chart .gd-axis .am .ics { font-size:16px; }
  .fx .gf-chart .gd-axis .am .dn { font-size:13px; }
  .panel-card:has(.gx) { background: linear-gradient(180deg, rgba(120,247,176,.06), transparent 160px), #0c1f19; }
  .gx { height:100%; overflow:auto; padding:4px 30px 30px; display:flex; flex-direction:column; gap:22px; }
  .gx-hero { display:flex; align-items:center; gap:22px; }
  .gx-hero .gd-day { font-size:92px; line-height:.8; }
  .gx-hero .gd-day small { display:block; font-size:14px; letter-spacing:.14em; margin:0 0 12px 4px; }
  .gx-id .st { font-family:var(--font-display); font-size:38px; font-weight:400; color:var(--mint); line-height:1; }
  .gx-id .sub { font-size:15px; color:var(--ink-soft); margin-top:8px; }

  .gx-tiles { display:grid; grid-template-columns:repeat(4, 1fr); gap:10px; }
  .gx-tile { border:1px solid var(--stroke); border-radius:18px; padding:14px 16px 13px;
        min-width:0; }
  .gx-tile.care { --c: #5fb6ff; }
  .gx-tile .l { font-size:22px; color:var(--c); display:flex; }
  .gx-tile .v { font-family:var(--font-display); font-size:44px; font-weight:700; color:var(--ink); line-height:1.05; margin-top:6px; }
  .gx-tile .v small { font-size:15px; font-weight:400; color:var(--ink-soft); margin-left:5px; }
  .gx-tile .v.t { font-size:22px; line-height:1.1; min-height:48px; display:flex; align-items:flex-end; }
  .gx-tile .s { font-size:13px; color:var(--ink-soft); margin-top:4px; white-space:nowrap; overflow:hidden; text-overflow:ellipsis; }

  .gx-sec { border:1px solid var(--stroke); border-radius:20px; padding:16px 18px 18px; min-width:0; }
  .gx-h { display:flex; align-items:baseline; justify-content:space-between; margin-bottom:14px;
    font-family:var(--font-mono); font-size:12.5px; letter-spacing:.18em; text-transform:uppercase; color:var(--ink-faint); }
  .gx-h .key { display:flex; align-items:center; gap:7px; letter-spacing:.08em; text-transform:none; font-size:12.5px; }
  .gx-h .key i { display:inline-block; width:16px; border-radius:3px; background:var(--ink-soft); margin-left:8px; }
  .gx-h .key i.k1 { height:4px; opacity:.4; }
  .gx-h .key i.k2 { height:8px; }

  .gf-chart .gd-rows { gap:4px; }
  .gf-chart .gd-row { flex-basis:24px; height:24px; }
  .gf-chart .gd-row .nm { font-size:16px; }
  .gf-chart .gd-row, .gf-chart .gd-axis, .gf-chart .gd-mlines { grid-template-columns: 170px 1fr 52px; }
  .gf-chart .gd-row .rt { font-size:13px; }
  .gf-chart .gd-axis { height:16px; margin:16px 0 6px; }
  .gf-chart .gd-axis .tk { font-size:12px; }
  .gf-chart .gd-axis .tk.today { top:-17px; color:var(--gold); font-weight:600; }

  .gx-bottom { display:grid; grid-template-columns:minmax(0,1fr) minmax(0,1.1fr); gap:12px; }
  .gx-tower { display:grid; grid-template-columns:minmax(0,1fr) 2px minmax(0,1fr); gap:0 10px; max-width:520px; margin:0 auto; }
  .gx-tower .spine { background:linear-gradient(180deg, transparent, var(--stroke-strong) 8%, var(--stroke-strong) 92%, transparent); border-radius:1px; }
  .gx-col { display:flex; flex-direction:column; gap:3px; }
  .gx-col:first-child .gx-pod { flex-direction:row-reverse; text-align:right; }
  .gx-pod { display:flex; align-items:center; gap:7px; height:34px; min-width:0; }
  .gx-pod i { width:12px; height:12px; border-radius:50%; flex:0 0 auto; box-shadow:0 0 0 3px rgba(255,255,255,.04); }
  .gx-pod .n { flex:1; min-width:0; font-size:13px; color:var(--ink); white-space:nowrap; overflow:hidden; text-overflow:ellipsis; }
  .gx-pod .ps { font-family:var(--font-mono); font-size:12px; width:16px; color:var(--ink-faint); flex:0 0 auto; }

  .gx-evs { display:flex; flex-direction:column; }
  .gx-ev { display:grid; grid-template-columns:54px 1fr auto; gap:10px; align-items:baseline;
    padding:8px 0; border-bottom:1px solid var(--stroke); }
  .gx-ev:first-child { padding-top:0; }
  .gx-ev .dt { font-family:var(--font-mono); font-size:12.5px; color:var(--ink-faint); white-space:nowrap; }
  .gx-sec.water .gx-ev { grid-template-columns:72px 1fr auto; }
  .gx-ev .t { font-size:16px; color:var(--ink); }
  .gx-ev .how { font-size:12.5px; color:var(--ink-soft); margin-top:2px; }
  .gx-ev .in { font-family:var(--font-mono); font-size:12.5px; color:var(--ink-soft); }
  .gx-ev.now .dt, .gx-ev.now .t, .gx-ev.now .in { color:var(--gold); }
  .gx-sec.water .gx-h > span:first-child { color:#5fb6ff; }
  .gx-ev.next .dt, .gx-ev.next .t, .gx-ev.next .in { color:#5fb6ff; }
  .gx-ev.refresh .t::after { content:' ↻'; color:var(--ink-faint); }
  .gx-ev.done .t { color:var(--mint); }
  .gx-ev .act { display:flex; flex-direction:column; align-items:flex-end; gap:6px; }
  .gx-btn { font-family:var(--font); font-size:13px; font-weight:600; color:#042018; background:var(--mint);
    border:none; border-radius:999px; padding:6px 13px; cursor: var(--c-hand); white-space:nowrap; }
  .gx-sec.water .gx-btn { background:#5fb6ff; }
  .gx-btn.ghost { background:transparent; color:var(--ink-soft); border:1px solid var(--stroke); padding:4px 11px; font-weight:400; }
  .gx-btn:disabled { opacity:.6; }
  .gx-ev.done { opacity:.7; }
  .gx-routine { margin-top:12px; display:flex; flex-direction:column; gap:5px; font-size:13px; color:var(--ink-soft); }
  .gx-routine b { color:var(--ink); font-weight:600; margin-right:4px; }
  .gf-src { font-size:12.5px; color:var(--ink-faint); }
  /* 2026-10-07 redesign: no boxes in the fullscreen either — open type + spacing. */
  .gx-tile { border:none; background:none; border-radius:0; padding:0; }
  .gx-sec { border:none; border-radius:0; padding:0; }
  .gx-tiles { gap:24px; }
  /* icon rows (water / tasks / done) */
  .gx-row { display:grid; grid-template-columns:34px 1fr auto 34px; gap:10px; align-items:center;
    padding:9px 0; border-bottom:1px solid var(--stroke); }
  .gx-row .ri { width:34px; height:34px; border-radius:50%; display:grid; place-items:center; font-size:17px;
    color:var(--c, var(--ink-soft)); background:color-mix(in srgb, var(--c, #fff) 13%, transparent); }
  .gx-row.top, .gx-row.refresh, .gx-row.dose { --c:#5fb6ff; }
  .gx-row.task { --c:var(--gold); }
  .gx-row.done { --c:var(--mint); opacity:.7; }
  .gx-row:not(.next):not(.now):not(.done) .ri { opacity:.6; }
  .gx-row .d { font-size:13px; color:var(--ink-soft); }
  .gx-row .m { font-size:16px; color:var(--ink); white-space:nowrap; overflow:hidden; text-overflow:ellipsis; }
  .gx-row .rn { font-family:var(--font-display); font-size:18px; color:var(--ink-soft); }
  .gx-row.next .rn, .gx-row.now .rn { color:var(--c); }
  .gx-btn { width:34px; height:34px; padding:0; display:grid; place-items:center; font-size:17px; border-radius:50%; }
  .gx-btn.err { background:var(--rose); }
  .gx-btn.ghost { padding:0; font-size:15px; }
  .gx-btn-sp { width:34px; }
  .gx-ramp { display:flex; align-items:center; gap:6px; margin-top:14px; font-size:15px; color:var(--ink-soft); }
  .gx-ramp .chip { display:inline-flex; align-items:center; gap:5px; padding:4px 10px; border-radius:999px;
    background:rgba(255,255,255,.05); color:var(--ink-soft); }
  .gx-ramp .chip.on { background:color-mix(in srgb, #5fb6ff 18%, transparent); color:#5fb6ff; }
  .gx-ramp .chip small { font-size:12.5px; color:var(--ink-faint); }
  .gx-ramp .per { margin-left:4px; font-size:13px; color:var(--ink-faint); }
  .gx-pod .ic.kind { font-size:13px; }
  .gx-row.tap { cursor: var(--c-hand); }
  .gx-btn.arm { background:var(--gold); box-shadow:0 0 0 3px color-mix(in srgb, var(--gold) 35%, transparent); }
  /* how-to view */
  .hw { gap:20px; }
  .hw-back { align-self:flex-start; margin-left:-6px; } /* look from the shared .gbtn */
  .hw-hero { display:flex; align-items:center; gap:18px; }
  .hw-ic { width:64px; height:64px; border-radius:50%; display:grid; place-items:center; font-size:30px; color:var(--gold);
    background:color-mix(in srgb, var(--gold) 15%, transparent); flex:0 0 auto; }
  .hw-t { font-family:var(--font-display); font-size:36px; color:var(--ink); line-height:1.05; }
  .hw-when { font-size:16px; color:var(--ink-soft); margin-top:4px; }
  .hw-need { display:flex; flex-wrap:wrap; align-items:center; gap:8px; }
  .hw-need .lbl { font-size:13px; color:var(--ink-faint); margin-right:4px; }
  .hw-need .chip { font-size:15px; color:var(--ink); background:rgba(255,255,255,.06); border-radius:999px; padding:6px 13px; }
  .hw-steps { margin:0; padding:0; list-style:none; counter-reset:st; display:flex; flex-direction:column; gap:14px; }
  .hw-steps li { counter-increment:st; display:grid; grid-template-columns:36px 1fr; gap:12px; align-items:start; font-size:19px; line-height:1.35; color:var(--ink); }
  .hw-steps li::before { content:counter(st); width:32px; height:32px; border-radius:50%; display:grid; place-items:center;
    font-family:var(--font-display); font-size:17px; color:#042018; background:var(--mint); }
  .hw-pods { display:grid; grid-template-columns:1fr 1fr; gap:6px 16px; }
  .hw-pod { display:flex; align-items:center; gap:8px; font-size:15px; color:var(--ink); padding:4px 0; }
  .hw-pod .ps { font-size:12px; color:var(--ink-faint); width:22px; }
  .hw-pod .n { flex:1; min-width:0; white-space:nowrap; overflow:hidden; text-overflow:ellipsis; }
  .hw-pod b { font-weight:600; font-size:14px; padding:2px 9px; border-radius:999px; }
  .hw-pod.k1 b { color:var(--mint); background:color-mix(in srgb, var(--mint) 14%, transparent); }
  .hw-pod.k3 b { color:#c3a8ff; background:color-mix(in srgb, #9a7cf0 18%, transparent); }
  .hw-qrs { display:flex; gap:28px; flex-wrap:wrap; }
  .hw-q { display:flex; align-items:center; gap:14px; }
  .hw-q b { font-size:17px; color:var(--ink); font-weight:600; }
  .hw-q .sub { font-size:13px; color:var(--ink-soft); margin-top:3px; max-width:200px; }
  .hw-qr { width:120px; height:120px; border-radius:12px; background:#fff; }
`;
