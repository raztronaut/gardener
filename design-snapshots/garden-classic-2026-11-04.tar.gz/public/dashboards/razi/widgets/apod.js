// Razi's dashboard — NASA's Astronomy Picture of the Day, big. (Restored from the
// main wall's old apod widget, retired in da13d7b, and given the full-width hero slot.) The image fills the card (object-fit:cover); the title + date float on
// a bottom gradient scrim. Data via the keyless DEMO_KEY endpoint through the
// SSRF-safe proxy; the image itself is also fetched through the proxy and only
// swapped in on a CLEAN decode (never a broken-image icon). APOD updates once a
// day, so we refresh every 6 hours and KEEP the last good render if a refresh
// fails. No perpetual animation — a single one-shot fade-in on image load.
//
// media_type may be "video" (~1 day in 20). We DON'T embed it (no iframe / no
// autoplay on this low-power kiosk): a calm placeholder card carries the title,
// date and a small "🎬 video — view on nasa.gov" caption instead.

const API = 'https://api.nasa.gov/planetary/apod?api_key=DEMO_KEY';
const PAGE = 'https://science.nasa.gov/apod/';

// The keyless DEMO_KEY is heavily rate-limited (~30-50 req/day per IP), so on a
// 24/7 kiosk the API call fails often. We persist the last GOOD picture to
// localStorage so a rate-limited / offline morning can still re-decode the most
// recent image from NASA's image CDN (a different host that usually stays up),
// instead of dropping to a bare placeholder.
const LS_KEY = 'apod:last:v1';
function saveCache(d) {
  try {
    localStorage.setItem(LS_KEY, JSON.stringify({
      url: d.url, title: d.title, date: d.date,
      copyright: d.copyright, explanation: d.explanation, media_type: d.media_type,
    }));
  } catch { /* private mode / quota — non-fatal */ }
}
function loadCache() {
  try { return JSON.parse(localStorage.getItem(LS_KEY) || 'null'); }
  catch { return null; }
}

// "2026-07-28" → "July 28, 2026" (parsed as a plain date, no timezone drift).
function fmtDate(iso) {
  const m = /^(\d{4})-(\d{2})-(\d{2})/.exec(iso || '');
  if (!m) return iso || '';
  const MON = ['January', 'February', 'March', 'April', 'May', 'June',
    'July', 'August', 'September', 'October', 'November', 'December'];
  const mon = MON[parseInt(m[2], 10) - 1] || '';
  return `${mon} ${parseInt(m[3], 10)}, ${m[1]}`;
}

// NASA's explanation arrives as one long paragraph, sometimes with double spaces
// and stray line breaks. Collapse it to a single clean run of text; the CSS
// line-clamp handles length, so we keep the full string for the tooltip.
function tidy(text) {
  return (text || '').toString().replace(/\s+/g, ' ').trim();
}

// A quiet freshness label for the picture's date, relative to "today" in the
// display timezone. NASA publishes a new APOD once a day, so this tells the wall
// at a glance whether it's looking at the very latest image. The two freshest
// days read in bright mint ("TODAY" / "YESTERDAY"); an older picture — the feed
// hasn't refreshed — reads as a muted "N DAYS AGO" so staleness is honest without
// shouting. A not-yet-local "tomorrow" edge case near midnight (days < 0) stays
// unlabelled. Returns { text, stale } or null.
function freshnessTag(iso, tz) {
  const a = /^(\d{4})-(\d{2})-(\d{2})/.exec(iso || '');
  if (!a) return null;
  const todayStr = new Intl.DateTimeFormat('en-CA', {
    timeZone: tz, year: 'numeric', month: '2-digit', day: '2-digit',
  }).format(new Date());
  const b = /^(\d{4})-(\d{2})-(\d{2})/.exec(todayStr);
  if (!b) return null;
  const days = Math.round(
    (Date.UTC(+b[1], +b[2] - 1, +b[3]) - Date.UTC(+a[1], +a[2] - 1, +a[3])) / 864e5);
  if (days < 0) return null;
  if (days === 0) return { text: 'TODAY', stale: false };
  if (days === 1) return { text: 'YESTERDAY', stale: false };
  return { text: `${days} DAYS AGO`, stale: true };
}

// Archival catalogue number — a museum-placard touch on the wall's one "art" piece.
// NASA has published an Astronomy Picture of the Day essentially every day since
// 1995-06-16, so the whole-day count from that first picture to THIS one is a
// faithful sense of how deep the archive runs ("№ 11,410" ≈ 31 years of daily
// images). Computed in UTC from the date parts (no timezone drift); the epoch day
// itself is № 1, and any pre-launch / unparseable date returns null so the placard
// simply hides. Exported for smoke — the epoch + inclusive count are the invariant.
const APOD_EPOCH_UTC = Date.UTC(1995, 5, 16); // 1995-06-16, the first APOD
export function catalogNumber(iso) {
  const m = /^(\d{4})-(\d{2})-(\d{2})/.exec(iso || '');
  if (!m) return null;
  const t = Date.UTC(+m[1], +m[2] - 1, +m[3]);
  const n = Math.floor((t - APOD_EPOCH_UTC) / 864e5) + 1;
  return n >= 1 ? n : null;
}

export default {
  id: 'apod',
  title: 'Astronomy Photo',
  icon: '🔭',
  size: 'hero', // full width × 2 rows — the one picture on Razi's dashboard
  chrome: true,

  async mount(body, ctx) {
    const { h } = ctx;
    const tz = ctx.config?.tz || 'America/Los_Angeles';
    ctx.style(`
      .apod { position:relative; width:100%; height:100%; min-height:0; border-radius:16px;
        overflow:hidden; background:#05070f; border:1px solid var(--stroke); }
      /* the photo fills the whole card; only fades in once it has cleanly decoded */
      .apod-img { position:absolute; inset:0; width:100%; height:100%; object-fit:cover;
        display:block; opacity:0; transition:opacity .7s ease; }
      .apod-img.in { opacity:1; }
      /* calm placeholder — a deep starfield wash beneath everything, shown until a
         frame decodes (and for video days). Never a bare black box / broken image. */
      .apod-ph { position:absolute; inset:0; display:flex; flex-direction:column;
        align-items:center; justify-content:center; gap:10px; text-align:center;
        color:var(--ink-soft); padding:24px;
        background:radial-gradient(130% 100% at 50% 30%, #16204a 0%, #0a0f28 48%, #05070f 100%); }
      .apod-ph .ic { font-size:38px; opacity:.7; filter:drop-shadow(0 2px 10px rgba(0,0,0,.5)); }
      .apod-ph .t { font-family:var(--font-mono); font-size:13px; letter-spacing:.06em;
        color:var(--ink-faint); }
      .apod-ph .sub { font-family:var(--font-mono); font-size:12px; letter-spacing:.05em;
        color:var(--ink-faint); opacity:.6; margin-top:-4px; }
      /* Last-resort fallback: a hand-composed on-brand starfield so a missing feed
         still reads as an intentional night-sky illustration, never a broken box.
         All layers are STATIC radial gradients (essentially free to render — no
         animation, no blur). A soft mint horizon glow ties it to the garden theme. */
      .apod-ph.stars {
        background:
          radial-gradient(1.6px 1.6px at 18% 24%, rgba(255,255,255,.95), transparent 60%),
          radial-gradient(1.2px 1.2px at 68% 16%, rgba(255,255,255,.75), transparent 60%),
          radial-gradient(1px 1px at 82% 40%, rgba(200,225,255,.8), transparent 60%),
          radial-gradient(1.4px 1.4px at 34% 58%, rgba(255,255,255,.7), transparent 60%),
          radial-gradient(1px 1px at 54% 30%, rgba(255,255,255,.55), transparent 60%),
          radial-gradient(1.2px 1.2px at 12% 66%, rgba(200,225,255,.65), transparent 60%),
          radial-gradient(1px 1px at 74% 72%, rgba(255,255,255,.6), transparent 60%),
          radial-gradient(1.5px 1.5px at 90% 62%, rgba(255,255,255,.7), transparent 60%),
          radial-gradient(1px 1px at 44% 82%, rgba(200,225,255,.55), transparent 60%),
          radial-gradient(2px 2px at 26% 12%, rgba(255,247,220,.9), transparent 55%),
          radial-gradient(120% 80% at 50% 118%, rgba(120,247,176,.14) 0%, transparent 60%),
          radial-gradient(130% 100% at 50% 22%, #1a2652 0%, #0a0f28 50%, #05070f 100%); }
      .apod-ph.stars .ic { opacity:.85; filter:drop-shadow(0 2px 14px rgba(120,247,176,.35)); }
      .apod-ph.stars .t { color:var(--ink-soft); }
      /* video-day placeholder carries the real title + date + a small caption.
         The big clapperboard icon is dropped here (the "🎬 video" pill below already
         signals a video), which frees the vertical room so the up-to-2-line title
         shows in full without the flex column squishing it into the date badge.
         Title/date/pill never shrink; only the caption clamps. */
      .apod-ph.vid { gap:12px; padding:20px; overflow:hidden; }
      .apod-ph.vid .ic { display:none; }
      .apod-ph.vid .vt { flex:0 0 auto; font-family:var(--font-display); font-weight:700; font-size:17px;
        line-height:1.26; color:var(--ink); max-width:94%;
        display:-webkit-box; -webkit-line-clamp:2; -webkit-box-orient:vertical; overflow:hidden; }
      .apod-ph.vid .vd { flex:0 0 auto; font-family:var(--font-mono); font-size:12.5px; letter-spacing:.05em;
        color:var(--ink-soft); display:inline-flex; align-items:center; gap:8px; flex-wrap:wrap;
        justify-content:center; }
      .apod-ph.vid .vc { flex:0 0 auto; display:inline-flex; align-items:center; gap:6px; margin-top:4px;
        padding:5px 12px; border-radius:999px; background:rgba(8,14,34,.6);
        border:1px solid var(--stroke-strong); font-family:var(--font-mono);
        font-size:12px; letter-spacing:.06em; color:var(--ink-soft); }
      /* archival catalogue placard — a hushed mono chip in the photo's top corner,
         like the little catalogue tag beside a curated museum print, naming how deep
         into NASA's 30-year daily archive this picture sits. Absolutely positioned in
         the photo's empty upper band (the caption scrim lives in the lower half), so
         it adds no height and can't clip; static, no animation. Its own dark, bordered
         pill + text-shadow keep it legible over any image, bright or dark. */
      .apod-cat { position:absolute; top:12px; right:13px; z-index:2; pointer-events:none;
        font-family:var(--font-mono); font-size:12px; letter-spacing:.11em; line-height:1;
        color:rgba(234,255,244,.64); background:rgba(5,8,16,.44);
        border:1px solid rgba(180,214,202,.18); border-radius:999px; padding:3.5px 9px;
        text-shadow:0 1px 5px rgba(0,0,0,.85); }
      .apod-cat .no { color:var(--mint-2); font-weight:700; margin-right:2px; }
      /* bottom scrim + caption overlaid on the photo — absolutely positioned so it
         can never push the card taller than its fixed 9:16 slot. */
      .apod-scrim { position:absolute; left:0; right:0; bottom:0; height:52%; pointer-events:none;
        background:linear-gradient(to top, rgba(0,0,0,.82) 0%, rgba(0,0,0,.5) 42%, transparent 100%); }
      .apod-cap { position:absolute; left:24px; right:24px; bottom:20px; }
      .apod-title { font-family:var(--font-display); font-weight:700; font-size:30px; line-height:1.22;
        color:#fff; text-shadow:0 1px 8px rgba(0,0,0,.7);
        display:-webkit-box; -webkit-line-clamp:2; -webkit-box-orient:vertical; overflow:hidden; }
      .apod-date { margin-top:6px; font-family:var(--font-mono); font-size:15px; letter-spacing:.05em;
        color:rgba(234,255,244,.72); text-shadow:0 1px 5px rgba(0,0,0,.7);
        white-space:nowrap; overflow:hidden; text-overflow:ellipsis; }
      .apod-date .cr { color:rgba(234,255,244,.5); }
      /* freshness chip — a hushed pill naming how recent the picture is, so a
         glance tells whether the wall is showing today's newest image. */
      .apod-fresh { display:inline-block; margin-right:8px; padding:1px 7px; border-radius:999px;
        font-family:var(--font-mono); font-size:11.5px; font-weight:700; letter-spacing:.1em;
        color:var(--mint); background:rgba(120,247,176,.16); border:1px solid rgba(120,247,176,.34);
        vertical-align:1px; text-shadow:none; }
      /* stale (2+ days old) — the feed hasn't refreshed; a hushed neutral pill
         so it's honest but never alarming. */
      .apod-fresh.stale { color:rgba(234,255,244,.6); background:rgba(255,255,255,.08);
        border-color:rgba(255,255,255,.16); }
      /* a quiet museum caption — NASA's own words on today's image, clamped to two
         lines so the photo stays the hero. Hidden entirely when absent. Sits over
         the scrim (absolutely positioned) so it can never grow the card's height. */
      .apod-desc { margin-top:10px; font-size:16px; line-height:1.45; font-weight:400;
        color:rgba(234,255,244,.84); text-shadow:0 1px 6px rgba(0,0,0,.85);
        display:-webkit-box; -webkit-line-clamp:3; -webkit-box-orient:vertical; overflow:hidden; }
      /* the same caption, styled for the video-day placeholder card */
      .apod-ph.vid .vx { flex:0 1 auto; min-height:0; margin-top:2px; max-width:94%; font-size:12.5px;
        line-height:1.44; color:var(--ink-soft);
        display:-webkit-box; -webkit-line-clamp:3; -webkit-box-orient:vertical; overflow:hidden; }
    `);
    body.classList.add('apod');

    // Placeholder shown until the first clean decode; stays in the DOM (behind the
    // image) so a decode failure just leaves the calm starfield, never blank.
    const phTxt = h('div', { class: 't' }, 'reaching for the stars…');
    const ph = h('div', { class: 'apod-ph' }, h('div', { class: 'ic' }, '🔭'), phTxt);
    const img = h('img', { class: 'apod-img', alt: '' });
    const titleEl = h('div', { class: 'apod-title' });
    const dateEl = h('div', { class: 'apod-date' });
    const descEl = h('div', { class: 'apod-desc' });
    const cap = h('div', { class: 'apod-cap' }, titleEl, dateEl, descEl);
    const scrim = h('div', { class: 'apod-scrim' });

    // Decode an image THROUGH the proxy into a detached Image; resolve only on a
    // clean load so we never swap in a broken frame. Reject on error/timeout.
    const decode = (src) => new Promise((resolve, reject) => {
      const pre = new Image();
      const to = setTimeout(() => { pre.onload = pre.onerror = null; reject(new Error('timeout')); }, 22000);
      pre.onload = () => { clearTimeout(to); resolve(pre.src); };
      pre.onerror = () => { clearTimeout(to); reject(new Error('decode')); };
      pre.src = ctx.proxyUrl(src);
    });

    // Render an IMAGE day: preload+decode FIRST, then reveal — so a failed refresh
    // never wipes a good picture already on screen.
    const renderPhoto = async (d) => {
      const src = await decode(d.url); // rejects → caller keeps the last good render
      img.src = src;
      titleEl.textContent = d.title || 'Astronomy Picture of the Day';
      const fresh = freshnessTag(d.date, tz);
      // NOTE: native Node.replaceChildren coerces a null argument into the literal
      // text node "null" (unlike ctx.h, which drops falsy children). On a public-
      // domain NASA day (no copyright) — or near midnight when the freshness tag is
      // absent — a bare `null` would glue onto the date ("August 26, 2026null"), so
      // build the children as an array and filter the falsy entries out.
      dateEl.replaceChildren(...[
        fresh ? h('span', { class: `apod-fresh${fresh.stale ? ' stale' : ''}` }, fresh.text) : null,
        fmtDate(d.date),
        d.copyright
          ? h('span', { class: 'cr' }, `  ·  © ${String(d.copyright).replace(/\s+/g, ' ').trim()}`) : null,
      ].filter(Boolean));
      // Museum caption — NASA's own words, clamped to two lines. Hidden when absent.
      const blurb = tidy(d.explanation);
      descEl.textContent = blurb;
      descEl.title = blurb;
      descEl.style.display = blurb ? '' : 'none';
      // Archival catalogue placard (top corner) — how deep into NASA's daily archive
      // this picture sits. Hidden when the date is missing/unparseable. Filtered out
      // of replaceChildren when null (a bare null would coerce to a "null" text node).
      const cat = catalogNumber(d.date);
      const catEl = cat ? h('div', {
        class: 'apod-cat',
        title: `№ ${cat.toLocaleString('en-US')} — day ${cat.toLocaleString('en-US')} of NASA's `
          + 'Astronomy Picture of the Day, which began June 16, 1995',
      }, h('span', { class: 'no' }, '№'), cat.toLocaleString('en-US')) : null;
      body.replaceChildren(...[img, scrim, catEl, cap].filter(Boolean));
      // one-shot fade-in (next frame so the transition takes)
      requestAnimationFrame(() => img.classList.add('in'));
    };

    // Render a VIDEO day (or an image with no usable url): a calm placeholder that
    // still shows the title + date. No iframe, no autoplay.
    const renderVideo = (d) => {
      const blurb = tidy(d.explanation);
      const fresh = freshnessTag(d.date, tz);
      body.replaceChildren(h('div', { class: 'apod-ph vid' },
        h('div', { class: 'ic' }, '🎬'),
        h('div', { class: 'vt' }, d.title || 'Astronomy Video of the Day'),
        h('div', { class: 'vd' },
          fresh ? h('span', { class: `apod-fresh${fresh.stale ? ' stale' : ''}` }, fresh.text) : null, fmtDate(d.date)),
        blurb ? h('div', { class: 'vx', title: blurb }, blurb) : null,
        h('div', { class: 'vc' }, '🎬 video — view on nasa.gov')));
    };

    const render = async (d) => {
      if (!d || (!d.url && d.media_type !== 'video')) throw new Error('empty');
      if (d.media_type === 'video' || !d.url) renderVideo(d);
      else await renderPhoto(d);
      body.dataset.loaded = '1';
      saveCache(d); // remember this good picture for rate-limited / offline days
    };

    // Last-resort fallback: a calm, on-brand starfield illustration that FILLS the
    // card so a missing feed reads as intentional, never a broken dark box.
    const showStarfield = (msg) => {
      body.replaceChildren(h('div', { class: 'apod-ph stars' },
        h('div', { class: 'ic' }, '✦'),
        h('div', { class: 't' }, msg || 'The night sky is resting'),
        h('div', { class: 'sub' }, 'new photo at dawn')));
    };

    // api.nasa.gov's APOD endpoint has been flaky (HTTP 500 on 2026-11-04) and
    // apod.nasa.gov now redirects to science.nasa.gov/apod/, so when the API fails
    // we read today's picture straight off NASA's APOD page (its media-detail hero:
    // image, title, explanation and the Date / Credit table).
    const fromPage = async () => {
      const doc = new DOMParser().parseFromString(await ctx.fetchText(PAGE), 'text/html');
      const hero = doc.querySelector('.hds-media-detail-hero');
      if (!hero) throw new Error('page layout changed');
      const meta = {};
      for (const row of hero.querySelectorAll('.media-detail-hero__meta-row')) {
        meta[tidy(row.querySelector('th')?.textContent).replace(/:$/, '').toLowerCase()] = tidy(row.querySelector('td')?.textContent);
      }
      const d = new Date(`${meta.date || ''} 12:00 UTC`);
      const img = hero.querySelector('.media-detail-hero__media img');
      return {
        title: tidy(hero.querySelector('h2')?.textContent),
        date: Number.isNaN(+d) ? '' : d.toISOString().slice(0, 10),
        url: img ? (img.getAttribute('src') || '').replace(/\?.*$/, '?w=1600&fit=clip') : '',
        media_type: img ? 'image' : 'video',
        copyright: meta['credit & copyright'] || meta.credit || '',
        explanation: tidy(hero.querySelector('.media-detail-hero__description')?.textContent)
          .replace(/^Explanation:\s*/, '').replace(/\s*Tomorrow's picture:.*$/, ''),
      };
    };
    const fetchApod = () => ctx.fetchJSON(API).then((d) => { if (!d || d.code || !d.title) throw new Error('api'); return d; }).catch(fromPage);

    try {
      body.replaceChildren(ph);

      // Initial load: retry a few times with short backoff so one slow/aborted
      // response doesn't leave a graceful error up for a whole refresh cycle.
      let ok = false;
      for (let attempt = 1; attempt <= 3 && !ok; attempt++) {
        try { await render(await fetchApod()); ok = true; }
        catch { if (attempt < 3) await new Promise((r) => setTimeout(r, 1200 * attempt)); }
      }
      if (!ok && !body.dataset.loaded) {
        // API failed (often DEMO_KEY rate-limiting). Try the last good picture from
        // cache — the image CDN usually stays up even when the API is throttled.
        const cached = loadCache();
        if (cached) { try { await render(cached); ok = true; } catch { /* fall through */ } }
        // Still nothing → a calm on-brand starfield illustration, never a bare box.
        if (!ok && !body.dataset.loaded) showStarfield();
      }

      // APOD changes once/day; check every 6 hours. On failure KEEP the last good
      // render (render() only replaces the DOM after a clean fetch + decode).
      // ctx.interval fires immediately, so skip that first synchronous tick — the
      // initial retry loop above already produced (or is producing) the first paint.
      let firstTick = true;
      ctx.interval(() => {
        if (firstTick) { firstTick = false; return; }
        fetchApod().then(render).catch(() => {});
      }, 6 * 60 * 60 * 1000);
    } catch (e) {
      // mount() must never throw — fall back to the calm starfield illustration.
      try { showStarfield(); } catch { body.replaceChildren(ph); }
    }
  },
};
